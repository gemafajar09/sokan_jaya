<?php 
include "tglindo.php";
include "koneksi.php";
?>
<section class="content">
  <div class="row">
    <!-- left column -->
    <!-- /.box -->
    <!--/.col (left) -->
    <!-- right column -->
    <div class="col-md-12">
      <!-- Horizontal Form -->
      <!-- /.box-header -->
      <!-- form start -->
      <div class="container-fluid">
        <br>       
        <div class="box table-responsive">
          <div class="box-header">
            <h3 class="box-title">Data Pemesanan</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>No</th>
                <th>Nama Penumpang</th>
                <th>Nama Loket</th>
                <th>Tanggal Berangkat</th>
                <th>Rute Perjalanan</th>
                <th>Jam Keberangkatan</th>
                <th>Jumlah Pesan</th>
                <th>Nomor Kursi</th>
                <th>Jumlah Bayar</th>
                <th>Aksi</th>
              </tr>
              </thead>
              <tbody>
             
              <?php
                    $sqlt = mysqli_query($koneksi,"SELECT * FROM tbl_pemesanan a LEFT JOIN jam b ON a.id_rute=b.mobil LEFT JOIN tbl_penumpang c ON a.id_penumpang=c.id_penumpang LEFT JOIN tbl_loket d ON a.id_loket=d.id_loket");
                    $no=1;
                    while($xx = mysqli_fetch_array($sqlt)){
                  ?>
                    <tr>
                    <td>
                        <?= $no++?></td>
                        <td><?= $xx['nama_penumpang'];?></td>
                        <td><?= $xx['nama_loket'];?></td>
                        <td><?= TanggalIndo($xx['tanggal_pesan']);?></td>
                        <td><?= $xx['tujuan'];?></td>
                        <td><?= $xx['jam'];?></td>
                        <td><?= $xx['jumlah_pesan'];?></td>
                        <td><?= $xx['no_kursi'];?></td>
                        <td>Rp.<?= number_format($xx['jumlah_bayar'],2)?></td>
                    <td>
                             <form action="hapus.php?id=<?= $xx['id_pesan']; ?>" method='post'>
                              <a href="?page=view&id=<?= $xx['id_pesan'] ?>" class="btn btn-warning fa fa-user">Views</a>
                                  <button type="submit" name="hapus_pemesanan" class=" btn btn-danger"><i  class=" fa fa-trash-o"></i></button>
                                </form>
                            </ul>
                         </td>
                    </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
            <!-- /.box -->
       </div>
    </div>
  </div>
</section>

<!-- Modal -->